
<h2>Hey, It's me <?php echo e($data->name); ?></h2> 
<br>
    


<strong><?php echo e($data->name); ?> </strong><br>
<strong><?php echo e($data->email); ?></strong> <br>
<strong><?php echo e($data->phone); ?></strong> <br>
<strong>Subject: </strong><?php echo e($data->subject); ?> <br>
<strong><?php echo e($data->message); ?> </strong><br><br>
  
  
Thank you
</body><?php /**PATH C:\xampp\htdocs\emailsend\resources\views/email/contact.blade.php ENDPATH**/ ?>