

<br>
    






<pre><b><?php echo e($data->message); ?></b> <pre><a href="https://www.intouchsoftware.co.in">InTouch Software Solutions.</a><br>
  
Thank you


</body><?php /**PATH C:\xampp\htdocs\ITSmail\resources\views/email/contact.blade.php ENDPATH**/ ?>