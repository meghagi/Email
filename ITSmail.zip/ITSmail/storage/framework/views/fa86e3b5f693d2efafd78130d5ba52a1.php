Email
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
    .box
    {
         width:600px;
         margin:0 auto;
         border:1px solid #ccc;
    }
    .haserror
    {
        border-color:#cc0000;
        background-color:#ffff99;
    }
    </style>
</head>
<body>
    <br>
    <div class="container box">
    <form action="<?php echo e(route('send-email')); ?>" name="myForm" method="post" >
    <?php echo csrf_field(); ?>
   
    <div class="form-group">
      <label for="Enter your Name"> Name:</label>
      <input type="text" class="form-control" id="fname" placeholder="Enter Name" name="name">
      <span class="text-danger">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>


        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </span>
    </div>
    <div class="form-group">
      <label for="Enter your Email"> Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email">
      <span class="text-danger">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>


        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </span>
    </div>
    <div class="form-group">
      <label for="Message">Enter your message:</label>
      <input type="textarea" class="form-control" id="message" placeholder="Entermessage " name="Message">
      <span class="text-danger">
        <?php $__errorArgs = ['Message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>


        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </span>
  
</div>
<div class="form-group">
   <input type="submit" class="btn btn-primary" name="submit"id="submit">
<a href="Login.php">Login</a>
  
</div>


</form>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\emailsend\resources\views/email/Email.blade.php ENDPATH**/ ?>