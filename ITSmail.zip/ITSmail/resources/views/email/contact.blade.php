
{{--<h2>Hey, It's me {{ $data->name }}</h2> --}}
<br>
    
{{--<strong>User details: </strong><br>--}}
{{--<strong>Name: </strong>{{ $data->name }} <br>
<strong>Email: </strong>{{ $data->email }} <br>
<strong>Phone: </strong>{{ $data->phone }} <br>
<strong>Subject: </strong>{{ $data->subject }} <br>
<strong>Message: </strong>{{ $data->message }} <br><br>--}}
{{--<strong>{{ $data->name }} </strong><br>
<strong>{{ $data->email }}</strong> <br>
<strong>{{ $data->phone }}</strong> <br>
<strong>Subject: </strong>{{ $data->subject }} <br>
<strong>{{ $data->message }} </strong><br><br>--}}


{{--<strong>Subject: </strong><b>{{ $data->subject }} </b><br>--}}
<pre><b>{{ $data->message }}</b> <pre><a href="https://www.intouchsoftware.co.in">InTouch Software Solutions.</a><br>
  
Thank you


</body>